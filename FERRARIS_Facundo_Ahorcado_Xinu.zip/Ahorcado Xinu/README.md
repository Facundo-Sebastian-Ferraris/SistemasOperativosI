# **Proceso de Colocación de Archivos** 📂✨

1. **`ANSI.h`** debe estar en la carpeta `include/` 🎨  
   *(libreria para movilidad y limpieza de la terminal)*.

2. **`xsh_ahorcado.c`** debe estar en la carpeta `shell/` 🎮  
   *(El juego del ahorcado integrado en tu shell personalizado)*.

---

## **Ejemplo Visual** 🖥️🔥  

![sample](./sample.gif)

---

## Modificaciones ⚙️

1. `printf()` $\rightarrow$ `kprintf()`
2. `system("/bin/stty raw");` $\rightarrow$ `control(CONSOLE, TC_MODER, 0, 0);`
3. `system("/bin/stty sane erase ^H");` $\rightarrow$ control(CONSOLE, TC_MODEC, 0, 0);`
